require(testthat)
require(sjemea)

test_package("sjemea")
