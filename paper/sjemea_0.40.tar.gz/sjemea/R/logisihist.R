## Show the ISI histogram with log along the x-axis by default.

## fold in code from: ~/proj/sangermea/logisi/logisi_only1.R
  
